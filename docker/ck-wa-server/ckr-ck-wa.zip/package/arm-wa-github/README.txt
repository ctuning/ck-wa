CK package for ARM workload automation
http://github.com/ARM-software/workload-automation
