ck run wa:andebench @run-andebench.json --repetitions=1
