ck run wa:youtube --scenario=fps --repetitions=1
