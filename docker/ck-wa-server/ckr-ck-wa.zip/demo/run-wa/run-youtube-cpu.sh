ck run wa:youtube --scenario=cpu --repetitions=1
