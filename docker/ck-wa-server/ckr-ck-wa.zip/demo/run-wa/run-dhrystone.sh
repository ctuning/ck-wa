ck run wa:dhrystone @run-dhrystone.json --repetitions=2
