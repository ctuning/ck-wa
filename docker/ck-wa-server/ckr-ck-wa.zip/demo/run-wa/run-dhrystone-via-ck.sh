ck pipeline program:dhrystone --target=$1 @run-dhrystone-via-ck.json
