ck run wa:skype --scenario=cpu --repetitions=1
