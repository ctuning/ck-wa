ck run wa:googlephotos @run-googlephotos.json --repetitions=1
